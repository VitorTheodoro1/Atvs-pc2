package ExercFormas;

public abstract class biDimensional implements Forma {
    
}
