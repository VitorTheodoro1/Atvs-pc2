package ExercFormas;

public abstract class Tridimensional implements Forma{

    public abstract double obterVolume();

}
