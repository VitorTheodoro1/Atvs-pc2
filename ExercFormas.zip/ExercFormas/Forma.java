package ExercFormas;

public interface Forma {

    public abstract double obterArea();
    public abstract int conferir(String formaPedida);
    public abstract int qualForma();
}
