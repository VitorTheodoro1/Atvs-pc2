package WorldofZull;

/**
 * 
 * -----------------LEIA ---------------------
 * Olá Professora
 * 
 * exercício complexo 13itens e to muito sem tempo
 * fiz 4 itens da lista 
 * so pra ganhar uma porcentagem não zerar :(
 * 
 * 
 * */


public class TesteJogo {
	public static void main(String[] args){
		Game game = new Game();
		game.play();
	}

}
